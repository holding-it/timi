(function ($) {

	jQuery(document).ready(function() {
		jQuery('.panel-heading a').click(function() {
			if($(this).parents('.panel-heading').hasClass('actives')){
				$('.panel-heading').removeClass('actives');
			}
			else {
				$('.panel-heading').removeClass('actives');
				$(this).parents('.panel-heading').addClass('actives');
			}
		});

		jQuery('.close-login').click(function() {
			$('#login-modal').modal('hide');
		});

		jQuery('.close-register').click(function() {
			$('#register-modal').modal('hide');
		});

		jQuery('.popup').on('click', function(){
			var w = 400, h = 400,
				left = Number((screen.width/2)-(w/2)), tops = Number((screen.height/2)-(h/2)),
				popupWindow = window.open(this.href, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=1, copyhistory=no, width='+w+', height='+h+', top='+tops+', left='+left);
			popupWindow.focus(); return false;
		});

	});

}(jQuery));

(function ($) {

	jQuery('.form-item-pass-pass1').ready(function() {
		$('.form-item-pass-pass1').removeClass('col-md-4');
		$('.form-item-pass-pass1').removeClass('col-sm-6');
	});

}(jQuery));

(function ($) {

	jQuery( document ).ajaxStop(function() {
		$('.form-item-pass-pass1').removeClass('col-md-4');
		$('.form-item-pass-pass1').removeClass('col-sm-6');
	});

}(jQuery));

(function ($) {

	jQuery( document ).ajaxStop(function() {
		$('.form-item-pass-pass2').removeClass('col-md-4');
		$('.form-item-pass-pass2').removeClass('col-sm-6');
	});

}(jQuery));

(function ($) {

	jQuery('.form-item-pass-pass2').ready(function() {
		$('.form-item-pass-pass2').removeClass('col-md-4');
		$('.form-item-pass-pass2').removeClass('col-sm-6');
	});

}(jQuery));

(function ($) {

	jQuery('.col-lg-3').ready(function() {
		$('.col-lg-3').addClass('col-md-3');
		$('.col-lg-3').addClass('col-sm-6');
		$('.col-lg-3').addClass('col-xs-12');


	});

}(jQuery));