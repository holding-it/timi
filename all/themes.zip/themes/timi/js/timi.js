(function ($) {

	jQuery(document).ready(function() {
		jQuery('.panel-heading a').click(function() {
			if($(this).parents('.panel-heading').hasClass('actives')){
				$('.panel-heading').removeClass('actives');
			}
			else {
				$('.panel-heading').removeClass('actives');
				$(this).parents('.panel-heading').addClass('actives');
			}
		});

		jQuery('.close-login').click(function() {
			$('#login-modal').modal('hide');
		});

		jQuery('.close-register').click(function() {
			$('#register-modal').modal('hide');
		});

		jQuery('.popup').on('click', function(){
			var w = 400, h = 400,
				left = Number((screen.width/2)-(w/2)), tops = Number((screen.height/2)-(h/2)),
				popupWindow = window.open(this.href, '', 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=1, copyhistory=no, width='+w+', height='+h+', top='+tops+', left='+left);
			popupWindow.focus(); return false;
		});

	});

}(jQuery));

(function ($) {

	jQuery('.form-item-pass-pass1').ready(function() {
		$('.form-item-pass-pass1').removeClass('col-md-4');
		$('.form-item-pass-pass1').removeClass('col-sm-6');
	});

}(jQuery));

(function ($) {

	jQuery( document ).ajaxStop(function() {
		$('.form-item-pass-pass1').removeClass('col-md-4');
		$('.form-item-pass-pass1').removeClass('col-sm-6');
	});

}(jQuery));

(function ($) {

	jQuery( document ).ajaxStop(function() {
		$('.form-item-pass-pass2').removeClass('col-md-4');
		$('.form-item-pass-pass2').removeClass('col-sm-6');
	});

}(jQuery));

(function ($) {

	jQuery('.form-item-pass-pass2').ready(function() {
		$('.form-item-pass-pass2').removeClass('col-md-4');
		$('.form-item-pass-pass2').removeClass('col-sm-6');
	});

}(jQuery));

(function ($) {

	jQuery('.col-lg-3').ready(function() {
		$('.col-lg-3').addClass('col-md-3');
		$('.col-lg-3').addClass('col-sm-6');
		$('.col-lg-3').addClass('col-xs-12');


	});

}(jQuery));

(function ($) {

	jQuery('.login_btn').on('click', function(){
		var w = $( window ).width();
		$("#login-modal .modal-content").css("width", "460px");
		$("#login-modal .modal-title").css({"margin-left": "0px", "font-size": "48px"});
		$('head').append('<style>#login-modal .form-item-name:before{margin-left: -45px;}</style>');
		$("#login-modal input.form-text").css({"margin-left": "0px", "width": "300px"});
		$('head').append('<style>#login-modal .form-item-pass::before{margin-left: -45px;}</style>');
		$("#login-modal .btn.btn-default.form-submit").css("left", "50px");
		$("#login-modal div#or").css("display", "block");
		$("#login-modal #user-register a").css("display", "block");
		$("#login-modal #lost-pass a").css({"margin-left": "0px", "top": "0px"});
		$('head').append('<style>.facebook-login::before{margin-left: 20px;}</style>');
		$(".facebook-login").css("margin-top", "10px");
		$(".facebook-login a").css("font-size", "19px");
		$(".alert-danger").css("display", "block");
		if (w < 480) {
			$("#login-modal .modal-content").css("width", "280px");
			$("#login-modal .modal-title").css({"margin-left": "-30px", "font-size": "30px"});
			$('head').append('<style>#login-modal .form-item-name:before{margin-left: -75px;}</style>');
			$("#login-modal input.form-text").css({"margin-left": "-30px", "width": "180px"});
			$('head').append('<style>#login-modal .form-item-pass::before{margin-left: -75px;}</style>');
			$("#login-modal .btn.btn-default.form-submit").css("left", "20px");
			$("#login-modal div#or").css("display", "none");
			$("#login-modal #user-register a").css("display", "none");
			$("#login-modal #lost-pass a").css({"margin-left": "-30px", "top": "-30px"});
			$('head').append('<style>.facebook-login::before{margin-left: -10px;}</style>');
			$(".facebook-login").css("margin-top", "-25px");
			$(".facebook-login a").css("font-size", "11px");
			$(".alert-danger").css("display", "none");	
		}
	});

}(jQuery));

(function ($) {

	jQuery('.btn.btn-default.form-submit').on('click', function(){
		var w = $( window ).width();
		console.log(w);
		$('head').append('<style>#login-modal .alert-danger{width: 344px; margin-left: 5px;}</style>');
		$('head').append('<style>#login-modal input.form-text{margin-left: 0px; width: 300px;}</style>');
		$('head').append('<style>#login-modal .btn.btn-default.form-submit{left: 50px;}</style>');			
		if (w < 480) {	
			$('head').append('<style>#login-modal .alert-danger{width: 278px; margin-left: -54px;}</style>');
			$('head').append('<style>#login-modal input.form-text{margin-left: -30px; width: 180px;}</style>');
			$('head').append('<style>#login-modal .btn.btn-default.form-submit{left: 20px;}</style>');
		}

	});

}(jQuery));	

(function ($) {

	jQuery( document ).ajaxStop(function() {
		jQuery('.btn.btn-default.form-submit').on('click', function(){
			var w = $( window ).width();
			console.log(w);
			$('head').append('<style>#login-modal .alert-danger{width: 344px; margin-left: 5px;}</style>');
			$('head').append('<style>#login-modal input.form-text{margin-left: 0px; width: 300px;}</style>');
			$('head').append('<style>#login-modal .btn.btn-default.form-submit{left: 50px;}</style>');			
			if (w < 480) {	
				$('head').append('<style>#login-modal .alert-danger{width: 278px; margin-left: -54px;}</style>');
				$('head').append('<style>#login-modal input.form-text{margin-left: -30px; width: 180px;}</style>');
				$('head').append('<style>#login-modal .btn.btn-default.form-submit{left: 20px;}</style>');
			}

		});
	});

}(jQuery));	

(function ($) {

	jQuery('.login_btn').on('click', function(){
		var w = $( window ).width();
		$("#register-modal .modal-content").css("width", "460px");
		$("#register-modal .modal-title").css({"margin-left": "0px", "font-size": "48px"});
		$('head').append('<style>.facebook-register::before{margin-left: 20px;}</style>');
		$(".facebook-register a").css("font-size", "19px");
		$('head').append('<style>#register-modal .form-item-name::before{margin-left: -45px;}</style>');
		$("#register-modal input.form-text").css({"margin-left": "0px", "width": "300px"});
		$('head').append('<style>#register-modal .form-item.form-item-mail.form-type-textfield.form-group::before{margin-left: -45px;}</style>');
		$("#register-modal .help-block").css({"margin-left": "-45px", "width": "350px"});
		$('head').append('<style>#register-modal .form-item.form-item-pass-pass1::before{margin-left: -45px;}</style>');
		$('head').append('<style>#register-modal .form-item-pass-pass2::before{margin-left: -45px;}</style>');
		$('head').append('<style>#register-modal button.btn.btn-success.form-submit::before{margin-left: -57px;}</style>');
		$("#register-modal .btn-success").css("margin-left", "45px");
		$("#register-modal div#or").css("display", "block");
		$("#register-modal div#user-register a").css("display", "block");
		$("#register-modal #lost-pass a").css({"position": "absolute", "margin-top": "0px", "margin-left": "0px"});
		if (w < 480) {
			$("#register-modal .modal-content").css("width", "280px");
			$("#register-modal .modal-title").css({"margin-left": "-30px", "font-size": "30px"});
			$('head').append('<style>.facebook-register::before{margin-left: -10px;}</style>');
			$(".facebook-register a").css("font-size", "11px");
			$('head').append('<style>#register-modal .form-item-name::before{margin-left: -75px;}</style>');
			$("#register-modal input.form-text").css({"margin-left": "-30px", "width": "180px"});
			$('head').append('<style>#register-modal .form-item.form-item-mail.form-type-textfield.form-group::before{margin-left: -75px;}</style>');
			$("#register-modal .help-block").css({"margin-left": "-75px", "width": "230px"});
			$('head').append('<style>#register-modal .form-item.form-item-pass-pass1::before{margin-left: -75px;}</style>');
			$('head').append('<style>#register-modal .form-item-pass-pass2::before{margin-left: -75px;}</style>');
			$('head').append('<style>#register-modal button.btn.btn-success.form-submit::before{margin-left: -59px;}</style>');
			$("#register-modal .btn-success").css("margin-left", "15px");
			$("#register-modal div#or").css("display", "none");
			$("#register-modal div#user-register a").css("display", "none");
			$("#register-modal #lost-pass a").css({"position": "absolute", "margin-top": "30px", "margin-left": "-30px"});

		}
	});

}(jQuery));

(function ($) {

	jQuery('.btn.btn-success.form-submit').on('click', function(){
		var w = $( window ).width();
		console.log(w);
		$('head').append('<style>#register-modal .alert-danger{width: 344px; margin-left: 5px;}</style>');
		$('head').append('<style>#register-modal input.form-text{margin-left: 0px; width: 300px;}</style>');
		$('head').append('<style>#register-modal .help-block{margin-left: -45px; width: 350px;}</style>');
		$('head').append('<style>#register-modal .btn-success{left: 45px;}</style>');			
		if (w < 480) {	
			$('head').append('<style>#register-modal .alert-danger{width: 278px; margin-left: -54px;}</style>');
			$('head').append('<style>#register-modal input.form-text{margin-left: -30px; width: 180px;}</style>');
			$('head').append('<style>#register-modal .help-block{margin-left: -76px; width: 235px;}</style>');
			$('head').append('<style>#register-modal .btn-success{margin-left: 14px;}</style>');
		}

	});

}(jQuery));	

(function ($) {

	jQuery( document ).ajaxStop(function() {
		jQuery('.btn.btn-success.form-submit').on('click', function(){
			var w = $( window ).width();
			console.log(w);
			$('head').append('<style>#register-modal .alert-danger{width: 344px; margin-left: 5px;}</style>');
			$('head').append('<style>#register-modal input.form-text{margin-left: 0px; width: 300px;}</style>');
			$('head').append('<style>#register-modal .help-block{margin-left: -45px; width: 350px;}</style>');
			$('head').append('<style>#register-modal .btn-success{left: 45px;}</style>');			
			if (w < 480) {	
				$('head').append('<style>#register-modal .alert-danger{width: 278px; margin-left: -54px;}</style>');
				$('head').append('<style>#register-modal input.form-text{margin-left: -30px; width: 180px;}</style>');
				$('head').append('<style>#register-modal .help-block{margin-left: -76px; width: 235px;}</style>');
				$('head').append('<style>#register-modal .btn-success{margin-left: 14px;}</style>');
			}

		});
	});

}(jQuery));	