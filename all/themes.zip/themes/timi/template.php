<?php

/**
 * @file
 * The primary PHP file for this theme.
 */
 
function timi_preprocess_page(&$variables) {
	drupal_add_js(drupal_get_path('theme', 'timi') .'/js/timi.js', array('type' => 'file', 'scope' => 'footer', 'weight' => 1));
}