/* 
 * UI enhancements for the imagecache edit form
 */
(function($){

  /**
   * None here at the moment :-)
   * Conditional form logic was moved to drupal FAPI #states instead.
   */

})(jQuery);

